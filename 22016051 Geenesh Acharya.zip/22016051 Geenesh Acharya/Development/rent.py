import function 
from datetime import datetime
import webbrowser
import random

file_name = "costume.txt"
totalPrice=0

class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'



def brand(amt):
    c_amt = amt
    brand = function.key_value_of_costume()
    for key, values in brand.items():
        if key == c_amt:
            for costumes in values:
                if costumes == values[1]:
                    brand = costumes
                    return brand

def costumeId():
    global id
    costumeId = function.key_value_of_costume()
    error = True
    while error:
        try:
            print("")
            id = int(input(color.BOLD +color.GREEN + "Please, Enter the Id of costume which you want to rent.\n" + color.END ))
            if id in costumeId:
                error = False
                return id 
            elif id <= 0 :
                print(color.BOLD+color.RED+color.UNDERLINE+"Given ID is Zero or Negative number. Please enter correct ID"+color.END)
            else:
                print(color.RED + color.Bold + color.UNDERLINE + "Your ID is currrntly unavailable.We only have one to five"+color.END)
                
        except:
            print(color.RED + color.BOLD + color.UNDERLINE + "Your ID is not available.Please enter available ID's" + color.END)
    return id

def rent(id):
    global dictionary
    global totalPrice
    costumeId= int(id)
    item_price = int(function.price(costumeId))
    dictionary = function.key_value_of_costume()
    c_quantity = function.quantity(costumeId)
    brand1 = brand(costumeId)
    custome_name = function.name(costumeId)

    for i, j in dictionary.items():
        if i == id:
            for items in j:
                Quantity = int(f"{j[3]}")
                break
    invalid = True
    while invalid:
        try:
            Quantity_of_costume = int(input(color.BOLD +color.GREEN + "Enter Quantity of costume:\n" + color.END))
            if Quantity < Quantity_of_costume:
                print(color.RED + color.BOLD + color.UNDERLINE+ "Sorry, Your costume is out of stock.We have shown available stock in table" + color.END)
            elif Quantity_of_costume <= 0 :
                print(color.RED+"Given ID is in Invalid Formate. Please enter correct Quantity"+ color.END)
            else:
                print(color.BOLD + color.BLUE + "Your Costume is successfully Rented" + color.END)
                invalid=False
        except:
            print(color.RED + color.BOLD + color.UNDERLINE+ "Please, Enter valid Quantity in integer to Rent."+ color.END)

    remaining = c_quantity - Quantity_of_costume
    totalPrice = item_price * Quantity_of_costume

    for keys, values in dictionary.items():
        if keys == costumeId:
            for costumes in values:
                if costumes == values[3]:
                    values[3] = costumes.replace(values[3], f"{remaining}")
    
    new_file = open("costume.txt", "w")
    for id, costumes in dictionary.items():
        new_file.write(f"{costumes[0]},{costumes[1]},{costumes[2]},{costumes[3]}\n")

    costume_list = f"\t\tName : {custome_name}\n\t\tBrand : {brand1}\n\t\tQuantity :{Quantity_of_costume}\n\t\tPrice : {totalPrice}\n\n"
    
    return totalPrice, brand1, Quantity_of_costume, costume_list

#Generating Invoice 
def invoice(brand, quantity , Price, details):
    valid = False
    while not valid:
        first_name = input(color.DARKCYAN + color.BOLD +"Enter your first Name: \n" + color.END)
        if first_name.isalpha():
            valid = True
        else:
            print(color.RED+color.BOLD+color.UNDERLINE+"Your Name must be alphabets."+ color.END)

    valid = False
    while not valid:
        last_name = input(color.DARKCYAN + color.BOLD +"Enter your last Name: \n" + color.END)
        if last_name.isalpha():
            valid = True
        else:
            print(color.RED+color.BOLD+color.UNDERLINE+"Your Name must be alphabets."+ color.END)

    customer_name = first_name + " " + last_name

    
    customer_address = input (color.DARKCYAN + color.BOLD + "Enter your Address : \n" + color.END)
    dt=str(datetime.now())
 
    s=random.randint(0,200)
    n=str(s)+customer_name+ ".txt"
    with open(n,"w+") as e:
        e.write( f'''
        
RENTING INVOICE 
Itahari
Sunsari,Nepal

                                Elevate Costume Store
                         __________________________________
                         On behalf of Elevate Costume Store, 
                    we wanted to say thank you for your purchase. 
===================================================================================
                                                         {datetime.now()}

Costumer Details

Name:     {customer_name}
Address:  {customer_address}
____________________________

Rented Item Details

{details}
                                
                        Total Price: ${totalPrice} 
____________________________

                            We know the world is full of choices
                                  Thank you for choosing us
_______________________________________________________________________________________
Terms and condition
Fine will be charged after five days

Bank
Prabhu Bank Limited
A/c no. 1234567890
9800967301
_________________________________________________________________________________________
''')
      

        webbrowser.open(n)          
      
#fine=
def invoice2(custom, brand1, quantity , Price, more_amount, totalPrice, details):
    valid = False
    while not valid:
        customer_name = input(color.DARKCYAN + color.BOLD +"Enter your Name:\n" + color.END)
        if customer_name.isalpha():    
            valid = True
        else:
            print(color.RED+color.BOLD+color.UNDERLINE+"Your Name must be in alphabates"+color.END)


    customer_address = input (color.DARKCYAN + color.BOLD +"Enter your Address :\n" + color.END)
    dt=str(datetime.now())

    s=random.randint(0,200)
    n=str(s)+customer_name+ ".txt"
    with open(n,"w+") as e:
        e.write( f'''
        
RETURN INVOICE 
Itahari
Sunsari,Nepal

                                Elevate Costume Store
                         __________________________________
                         On behalf of Elevate Costume Store, 
                    we wanted to say thank you for your purchase. 
===================================================================================
                                                         {datetime.now()}
Costumer Details

Name:     {customer_name}
Address:  {customer_address}
____________________________

Return Item Details

{details}
____________________________
                                    We're so lucky to have customers like you!
Fine:        ${more_amount}
___________________________
Total Price: ${totalPrice} 
____________________________

                            We know the world is full of choices
                                  Thank you for choosing us
_______________________________________________________________________________________
Terms and condition
Fine will be charged after five days

Bank
Prabhu Bank Limited
A/c no. 1234567890
9800967301
_________________________________________________________________________________________
''')
        webbrowser.open(n)          

