import rent
import function
file_name = "costume.txt"

class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'
id=0

def welcome():
    print(color.BOLD + color.DARKCYAN + "_"*74 + color.END) 
    print(color.BOLD + color.GREEN + "="*74 + color.END)
    print(color.BOLD+color.PURPLE + """
    
    ██╗    ██╗███████╗██╗      ██████╗ ██████╗ ███╗   ███╗███████╗
    ██║    ██║██╔════╝██║     ██╔════╝██╔═══██╗████╗ ████║██╔════╝
    ██║ █╗ ██║█████╗  ██║     ██║     ██║   ██║██╔████╔██║█████╗  
    ██║███╗██║██╔══╝  ██║     ██║     ██║   ██║██║╚██╔╝██║██╔══╝  
    ╚███╔███╔╝███████╗███████╗╚██████╗╚██████╔╝██║ ╚═╝ ██║███████╗
     ╚══╝╚══╝ ╚══════╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝     ╚═╝╚══════╝                                                           

                 """ + color.END)
    print(color.BOLD + color.RED+ " "*30 +"𝐓𝐨 𝐄𝐋𝐄𝐕𝐀𝐓𝐄"+ color.END)  
    print(color.BOLD + color.GREEN + "="*23 + color.END + color.BOLD+ color.PURPLE + "We're glad you've chosen us,"+ color.END + color.BOLD + color.GREEN+ "="*23 + color.END )
    print(color.BOLD + color.GREEN + "*"*4 + color.BOLD+ color.PURPLE + "We want to show our appreciation by giving you a special incentive"+color.END + color.END+color.BOLD+ color.GREEN + "*"*4 + color.END)
    print(color.BOLD + color.DARKCYAN + "_"*74 + color.END) 

def show_option(): 
    print( color.BOLD + color.PURPLE+"""
    1: For Rent costume
    2: For Return costume
    3: Exit From Programme
    """ + color.END)

#Creating Dictonary
def key_value_of_costume():
    file = open(file_name,'r')
    dictonary = {}
    id = 1
    for fi in file:
        dictonary[id] = fi.replace("\n","").split(",")
        id +=1
    return dictonary

#Formate for Table
def show_costume_in_tabular_form():
    print(color.BOLD + color.BLUE +"{:5}".format("   Id")+"{:40}".format("     Costume Name")+"{:20}".format("Brand")+"{:20}".format("Rent Price")+"{:20}".format("Quantity")+ color.END)
    print(color.PURPLE +"_"*100 + color.END)
    for key, value in key_value_of_costume().items():
        print(color.YELLOW +"{:5}".format(key)+"{:40}".format("     "+value[0])+"{:20}".format(value[1])+"{:20}".format(value[2])+"{:20}".format(value[3])+ color.END)
        print(color.YELLOW +"_"*100 + color.END)
    print(color.BOLD + color.RED + "="*100 + color.END)

#It takes Id Frome user
def return_costumeId():
    global id
    costumeId = key_value_of_costume()
    error = True
    while error:
        try:
            print("")
            id = int(input(color.BOLD +color.GREEN + "Please, Enter the Id of costume which you want to return.\n" + color.END ))
            if id in costumeId:
                error = False
                return id 
            elif id <= 0 :
                print(color.RED + color.BOLD+ color.UNDERLINE+ "Given ID is Invalid. Please enter correct ID"+color.END)
            else:
                print(color.RED + color.Bold + color.UNDERLINE + "Your ID is currrntly unavailable.We only have one to five"+color.END)
                
        except:
            print(color.RED + color.BOLD + color.UNDERLINE + "Your ID is not available.Please enter available ID's" + color.END)
    return id

def quantity(id):
    c_id = id
    for i, j in key_value_of_costume().items():
        if i == c_id:
            for items in j:
                if items == j[3]:
                    quantity1 = int(items)
    return quantity1

#Total Rent price
def price(amt):
    c_amt = amt
    amount = key_value_of_costume()
    for key, values in amount.items():
        if key == c_amt:
            for costumes in values:
                if costumes == values[2]:
                    price = int(costumes.replace("$", ""))
                    return price

def name(amt):
    c_amt = amt
    amount = key_value_of_costume()
    for key, values in amount.items():
        if key == c_amt:
            for costumes in values:
                if costumes == values[0]:
                    name = costumes
                    return name

def brand(amt):
    c_amt = amt
    brand = key_value_of_costume()
    for key, values in brand.items():
        if key == c_amt:
            for costumes in values:
                if costumes == values[1]:
                    brand = costumes
                    return brand
              
def  return_costume(id):
    dictionary = key_value_of_costume()
    item_price = function.price(id)
    Quantityy = function.quantity(id)
    brand1 = rent.brand(id)
    custome_name = name(id)

    for i, j in dictionary.items():
        if i == id:
            for items in j:
                Quantity = int(f"{j[3]}")
                break
    invalid = True
    while invalid:
        try:
            Quantity_of_costume = int(input(color.BOLD +color.GREEN + "Enter Quantity of costume to return :\n" + color.END))
            if Quantity_of_costume <= 0 :
                print(color.RED + color.BOLD + color.UNDERLINE +"Given ID is in Invalid Formate. Please enter correct Quantity"+ color.END)
            else:
                invalid = False
                total = item_price*Quantity_of_costume  

        except:
            print(color.RED + color.BOLD + color.UNDERLINE + "Please, Enter valid Quantity in integer to Rent."+ color.END)

    #Fine Calculation
    while True:
        try:
            rent_day = int(input(color.BOLD +color.GREEN +"How many days the costume rented ?\n"+color.END))
        except:
            print(color.BOLD +color.RED + color.UNDERLINE + "Days cannot be in negative. Enter valid days.\n" +color.END)
            continue
        if rent_day >5:
            more_days=rent_day-5
            more_amount=5*more_days*total/100
            break
        elif rent_day<0:
            print (color.BOLD +color.RED + color.UNDERLINE +"Days cannot be in negative. Enter valid days.\n"+ color.END)
            continue
        else:
            more_amount=0
            break
            
    newQuantity = Quantity + Quantity_of_costume
    totalPrice = item_price*Quantity_of_costume+more_amount


    for keys, values in dictionary.items():
        if keys == id:
            values[3] = newQuantity

    new_file = open("costume.txt", "w")
    for key, costumes in dictionary.items():
        new_file.write(f"{costumes[0]},{costumes[1]},{costumes[2]},{costumes[3]}\n")

    costume_list = f"\t\tName : {custome_name}\n\t\tBrand : {brand1}\n\t\tQuantity :{Quantity_of_costume}\n\n"

    return custome_name , totalPrice, brand1, Quantity_of_costume, more_amount, costume_list
