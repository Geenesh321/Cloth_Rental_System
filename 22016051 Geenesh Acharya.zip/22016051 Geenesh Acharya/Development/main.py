import function
import rent
function.welcome()

class color:
   PURPLE = '\033[95m'
   CYAN = '\033[96m'
   DARKCYAN = '\033[36m'
   BLUE = '\033[94m'
   GREEN = '\033[92m'
   YELLOW = '\033[93m'
   RED = '\033[91m'
   BOLD = '\033[1m'
   UNDERLINE = '\033[4m'
   END = '\033[0m'

continue_loop = True
while continue_loop:
    function.show_option()
    try:
        option = int(input(color.BOLD +color.BLUE + "Enter your option:\n"+color.END))
        print("")
    except: 
        print(color.RED + color.BOLD+ color.UNDERLINE+ "Invalid Option.Your data is in string please entered in Integer"+color.END)
        continue

    if option == 1:
        details = ""
        function.show_costume_in_tabular_form()
        continue_rent = True
        while continue_rent:
            validId = rent.costumeId()
            t_price, brand2, quantity, costume_list = rent.rent(validId)
            details = details + costume_list
            ask = True
            while ask:
                yn = input(color.GREEN + color.BOLD + "Do you want to rent more ? (Yes/NO)\n" + color.END )
                if yn == "Yes" or yn ==  "y" or yn ==  "yes":
                    ask = False
                    continue
                elif yn == "No" or yn ==  "n" or yn ==  "no":
                    continue_rent = False
                    rent.invoice(brand2, quantity, t_price, details)
                    ask = False
                else:
                    print(color.RED + color.BOLD + color.UNDERLINE + "Sorry, Please Enter Yes or No to continue\n" + color.END )
    elif option == 2:
            details = ""
            total = 0
            print(color.BOLD +color.BLUE + color.UNDERLINE + "Welcome to Return option\n" + color.END)
            function.show_costume_in_tabular_form()
            continue_return = True
            while continue_return:
                custom, t_price, brand1, quantity1, more_amount, costume_list = function.return_costume(function.return_costumeId())
                total = total + int(t_price)
                details = details + costume_list

                ask = True
                while ask:
                    yn = input(color.GREEN + color.BOLD + "Do you want to return more ? (Yes/NO)\n" + color.END )
                    if yn == "Yes" or yn ==  "y" or yn ==  "yes":
                        ask = False
                        continue
                    elif yn == "No" or yn ==  "n" or yn ==  "no":
                        continue_return = False
                        rent.invoice2(custom , brand1, quantity1, t_price, more_amount, total, details)
                        ask = False
                    else:
                        print(color.RED + color.BOLD + color.UNDERLINE + "Error, Enter Yes or No\n" + color.END )          
                 
    elif option ==3:
            print(color.BOLD +color.BLUE +"Our thoughts and prayers are with you."+ color.END)
            print(color.YELLOW + "="*39 + color.END)
            print(color.RED +color.BOLD+ color.UNDERLINE+ "Your programe is closed" + color.END)
            print(color.YELLOW + "-"*24 + color.END)
            continue_loop = False
    else:
        print( color.BOLD + color.RED + color.UNDERLINE + "Your input was invalid. Please provide a valid integer between 1 and 3." + color.END)
        continue